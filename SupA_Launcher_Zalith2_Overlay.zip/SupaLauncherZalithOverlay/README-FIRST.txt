SUPA LAUNCHER — ZALITH 2 OVERLAY
================================

WHAT THIS PACK DOES
- Replaces the main launcher home screen with a glossy landscape dashboard.
- Keeps Zalith Launcher's existing navigation, account manager, version manager,
  settings screens, task system and real Minecraft launch event callbacks.
- Adds a quick multiplayer address dialog.
- Shows active background tasks with a progress bar, rate, elapsed timer and a
  rough remaining-time estimate based on the progress seen while the dashboard
  is open.
- Changes the displayed product name to SupA Launcher and uses a separate Android
  application ID so it can be installed alongside the upstream app.
- Adds a GitHub Actions workflow to build an ARM64 debug APK.

IMPORTANT LIMITS
This is a source overlay, not a copy of the entire 900 MB-class source repository.
It must be placed on top of a fresh ZalithLauncher2 source checkout/fork. The
upstream native code, version management and download engines are deliberately
retained instead of being replaced with fake implementations.
The overlay has not been compiled in this environment because the Android source
checkout/build toolchain is not available here. GitHub Actions performs the real
build in your repository. Review the Actions log if upstream changes break an
integration point.

INSTALL — GITHUB WEBSITE
1. Open YOUR ZalithLauncher2 fork on GitHub.
2. Open the repository root (the page that shows gradlew, settings.gradle.kts,
   ZalithLauncher/, PetLib/, etc.).
3. Upload the files and folders from this ZIP into that repository root. Do not
   upload the outer SupaLauncherZalithOverlay folder itself as a nested folder.
4. Make sure these paths exist in the repository:
   - ZalithLauncher/src/main/java/com/movtery/zalithlauncher/ui/screens/content/SupaDashboard.kt
   - tools/apply_supa_patch.py
   - .github/workflows/supa-build.yml
5. Commit the upload.
6. Open the repository's Actions tab.
7. Select "Build SupA Launcher APK".
8. Press "Run workflow" and keep architecture as "arm64" for most modern Android
   phones. Press the green Run workflow button.
9. Wait for the workflow to finish. Open the completed run and download the
   "SupA-Launcher-arm64-debug" artifact. Unzip it and install the APK.

LOCAL BUILD
From the repository root, run:
  python3 tools/apply_supa_patch.py
  ./gradlew :ZalithLauncher:assembleDebug -Darch=arm64

WINDOWS LOCAL BUILD
Run the Python script from the repository root, then:
  gradlew.bat :ZalithLauncher:assembleDebug -Darch=arm64

UPSTREAM LICENSE / NAME REQUIREMENTS
Zalith Launcher 2 is GPL-3.0. Keep the upstream LICENSE file and all copyright
notices. This modified app is named "SupA Launcher" and its home screen visibly
says "UNOFFICIAL MODIFIED VERSION". Do not present it as the official Zalith app.
The module's source namespace remains unchanged for compatibility; the Android
application ID is changed to app.supacloud.supa.

FUNCTIONALITY MAP
The PLAY button calls the original launch callback. Account, version, settings,
multiplayer, file, download, mod, shader and world management are the original
launcher screens/engines. The SupA home screen is a redesign and quick-navigation
layer; it does not independently reimplement Microsoft OAuth, Minecraft asset
resolution, JVM setup or mod loaders.
