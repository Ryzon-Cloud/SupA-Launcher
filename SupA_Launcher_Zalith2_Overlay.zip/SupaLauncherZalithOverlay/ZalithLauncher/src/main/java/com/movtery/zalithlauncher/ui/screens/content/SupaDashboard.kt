/*
 * SupA Launcher - unofficial modified version of Zalith Launcher 2.
 * Copyright (C) 2026 SupA Launcher contributors.
 *
 * This file is distributed under the GNU GPL v3.0 or later.
 * The original launcher engine and its notices remain in the upstream source tree.
 */
package com.movtery.zalithlauncher.ui.screens.content

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movtery.zalithlauncher.coroutine.Task
import com.movtery.zalithlauncher.coroutine.TaskSystem
import com.movtery.zalithlauncher.game.account.AccountsManager
import com.movtery.zalithlauncher.game.account.getAccountTypeName
import com.movtery.zalithlauncher.game.version.installed.Version
import com.movtery.zalithlauncher.game.version.installed.VersionsManager
import com.movtery.zalithlauncher.ui.AndroidStringText
import com.movtery.zalithlauncher.ui.screens.NormalNavKey
import com.movtery.zalithlauncher.ui.screens.navigateTo
import com.movtery.zalithlauncher.ui.screens.content.elements.PlayerFace
import com.movtery.zalithlauncher.viewmodel.ScreenBackStackViewModel
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private val SupaInk = Color(0xFF080B12)
private val SupaPanel = Color(0xFF111827)
private val SupaPanel2 = Color(0xFF172235)
private val SupaText = Color(0xFFF4F7FC)
private val SupaMuted = Color(0xFF9AA8BA)
private val SupaAccent = Color(0xFFFFD34D)
private val SupaMint = Color(0xFF66E3C4)

@Composable
fun SupaDashboard(
    backStackViewModel: ScreenBackStackViewModel,
    onLaunchGame: (Version?) -> Unit,
    onQuickPlayServer: (Version?, String) -> Unit,
    onOpenVersionSettings: (Version) -> Unit,
    onOpenLink: (String) -> Unit
) {
    val account by AccountsManager.currentAccountFlow.collectAsStateWithLifecycle()
    val version by VersionsManager.currentVersion.collectAsStateWithLifecycle()
    val versions by VersionsManager.versions.collectAsStateWithLifecycle()
    val isRefreshing by VersionsManager.isRefreshing.collectAsStateWithLifecycle()
    val tasks by TaskSystem.tasksFlow.collectAsStateWithLifecycle()

    var showJoinDialog by remember { mutableStateOf(false) }
    var showVersionMenu by remember { mutableStateOf(false) }
    var serverAddress by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf<String?>(null) }
    var noticeKey by remember { mutableIntStateOf(0) }

    fun notifyUser(message: String) {
        notice = message
        noticeKey++
    }

    LaunchedEffect(noticeKey) {
        if (notice != null) {
            delay(3_200)
            notice = null
        }
    }

    val glowTransition = rememberInfiniteTransition(label = "supa-glow")
    val glowAlpha by glowTransition.animateFloat(
        initialValue = 0.20f,
        targetValue = 0.48f,
        animationSpec = infiniteRepeatable(tween(1_800), RepeatMode.Reverse),
        label = "supa-glow-alpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF080B12), Color(0xFF101725), Color(0xFF080D16))
                )
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SupaSidebar(
                onHome = { notifyUser("You're already on Home") },
                onVersions = {
                    backStackViewModel.mainScreen.navigateTo(NormalNavKey.VersionsManager)
                },
                onAccounts = {
                    backStackViewModel.mainScreen.navigateTo(NormalNavKey.AccountManager())
                },
                onSettings = {
                    backStackViewModel.mainScreen.removeAndNavigateTo(
                        removes = backStackViewModel.clearBeforeNavKeys,
                        screenKey = backStackViewModel.settingsScreen
                    )
                },
                onMultiplayer = {
                    backStackViewModel.mainScreen.navigateTo(NormalNavKey.Multiplayer)
                }
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "SUPA LAUNCHER",
                            color = SupaText,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            letterSpacing = 1.8.sp
                        )
                        Text(
                            text = "UNOFFICIAL MODIFIED VERSION",
                            color = SupaAccent,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                    }
                    StatusPill(text = if (isRefreshing) "SCANNING" else "READY")
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GlassPanel(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            glow = glowAlpha
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                StatusPill(text = "JAVA EDITION")
                                Spacer(Modifier.width(8.dp))
                                Text("ANDROID • LANDSCAPE", color = SupaMuted, fontSize = 9.sp)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(
                                text = "YOUR NEXT\nWORLD STARTS HERE.",
                                color = SupaText,
                                fontSize = 27.sp,
                                lineHeight = 30.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.2.sp
                            )
                            Text(
                                text = "A focused home for Minecraft Java. Pick a version, tune your setup, and jump in.",
                                color = SupaMuted,
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                                modifier = Modifier.fillMaxWidth(0.82f)
                            )
                            Spacer(Modifier.weight(1f))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Box {
                                    Column(Modifier.clickable { showVersionMenu = true }) {
                                        Text("SELECTED VERSION  ▾", color = SupaMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = version?.getVersionName() ?: "No version selected",
                                            color = SupaText,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = version?.getVersionSummary() ?: "Install or select a game version",
                                            color = SupaMuted,
                                            fontSize = 10.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = showVersionMenu,
                                        onDismissRequest = { showVersionMenu = false }
                                    ) {
                                        versions.forEach { candidate ->
                                            DropdownMenuItem(
                                                text = { Text(candidate.getVersionName()) },
                                                onClick = {
                                                    VersionsManager.saveVersion(candidate)
                                                    showVersionMenu = false
                                                    notifyUser("Selected ${candidate.getVersionName()}")
                                                }
                                            )
                                        }
                                        DropdownMenuItem(
                                            text = { Text("Manage versions…") },
                                            onClick = {
                                                showVersionMenu = false
                                                backStackViewModel.mainScreen.navigateTo(NormalNavKey.VersionsManager)
                                            }
                                        )
                                    }
                                }
                                Button(
                                    onClick = {
                                        if (version == null) {
                                            backStackViewModel.mainScreen.navigateTo(NormalNavKey.VersionsManager)
                                        } else {
                                            notifyUser("Starting Minecraft…")
                                            onLaunchGame(version)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SupaAccent,
                                        contentColor = Color(0xFF17130A)
                                    ),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Text(
                                        text = if (version == null) "INSTALL VERSION" else "PLAY NOW  ▶",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(90.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MiniStat(
                                modifier = Modifier.weight(1f),
                                label = "INSTALLED VERSIONS",
                                value = versions.size.toString(),
                                hint = "Manage game profiles"
                            ) {
                                backStackViewModel.mainScreen.navigateTo(NormalNavKey.VersionsManager)
                            }
                            MiniStat(
                                modifier = Modifier.weight(1f),
                                label = "ACCOUNT",
                                value = account?.username ?: "Not signed in",
                                hint = if (account == null) "Add or choose an account" else getAccountTypeName(account!!)
                            ) {
                                backStackViewModel.mainScreen.navigateTo(NormalNavKey.AccountManager())
                            }
                        }
                    }

                    Column(
                        modifier = Modifier
                            .width(218.dp)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GlassPanel(modifier = Modifier.fillMaxWidth()) {
                            Text("PLAYER PROFILE", color = SupaMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (account != null) {
                                    PlayerFace(account = account!!, avatarSize = 48.dp)
                                } else {
                                    Box(
                                        Modifier
                                            .size(48.dp)
                                            .clip(CircleShape)
                                            .background(SupaPanel2),
                                        contentAlignment = Alignment.Center
                                    ) { Text("＋", color = SupaAccent, fontSize = 25.sp) }
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        account?.username ?: "Guest player",
                                        color = SupaText,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        account?.let(::getAccountTypeName) ?: "Account not selected",
                                        color = SupaMuted,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            OutlinedButton(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    backStackViewModel.mainScreen.navigateTo(NormalNavKey.AccountManager())
                                },
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, Color(0xFF39475B))
                            ) { Text(if (account == null) "ADD ACCOUNT" else "MANAGE ACCOUNT", fontSize = 10.sp) }
                        }

                        GlassPanel(modifier = Modifier.fillMaxWidth().weight(1f)) {
                            Text("QUICK ACCESS", color = SupaMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(Modifier.height(8.dp))
                            QuickAction("▦", "Versions & profiles") {
                                backStackViewModel.mainScreen.navigateTo(NormalNavKey.VersionsManager)
                            }
                            QuickAction("◆", "Mods, shaders & worlds") {
                                version?.let(onOpenVersionSettings) ?: backStackViewModel.mainScreen.navigateTo(NormalNavKey.VersionsManager)
                            }
                            QuickAction("⇄", "Quick multiplayer") { showJoinDialog = true }
                            QuickAction("⚙", "Launcher settings") {
                                backStackViewModel.mainScreen.removeAndNavigateTo(
                                    removes = backStackViewModel.clearBeforeNavKeys,
                                    screenKey = backStackViewModel.settingsScreen
                                )
                            }
                            QuickAction("↗", "Project source") {
                                onOpenLink("https://github.com/ZalithLauncher/ZalithLauncher2")
                            }
                        }
                    }
                }

                if (tasks.isNotEmpty()) {
                    GlassPanel(modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("LIVE ACTIVITY", color = SupaText, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                            Spacer(Modifier.weight(1f))
                            StatusPill(text = "${tasks.size} ACTIVE")
                        }
                        Spacer(Modifier.height(5.dp))
                        tasks.take(2).forEach { task ->
                            SupaTaskRow(task = task)
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth().height(30.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("SUPA READY", color = SupaMint, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Spacer(Modifier.weight(1f))
                        Text("Minecraft engine powered by the original open-source launcher core", color = SupaMuted, fontSize = 9.sp)
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = notice != null,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp),
            enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut()
        ) {
            Surface(
                color = Color(0xF21A2637),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFF52637A)),
                shadowElevation = 12.dp
            ) {
                Column(Modifier.width(280.dp).padding(12.dp)) {
                    Text(notice.orEmpty(), color = SupaText, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Spacer(Modifier.height(7.dp))
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(3.dp),
                        color = SupaAccent,
                        trackColor = Color(0xFF354255)
                    )
                    Text("This message closes automatically", color = SupaMuted, fontSize = 9.sp, modifier = Modifier.padding(top = 5.dp))
                }
            }
        }
    }

    if (showJoinDialog) {
        AlertDialog(
            onDismissRequest = { showJoinDialog = false },
            title = { Text("Quick multiplayer") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter a server address. The selected Minecraft version will be used.")
                    OutlinedTextField(
                        value = serverAddress,
                        onValueChange = { serverAddress = it },
                        singleLine = true,
                        label = { Text("play.example.net:25565") }
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = serverAddress.isNotBlank(),
                    onClick = {
                        val address = serverAddress.trim()
                        showJoinDialog = false
                        notifyUser("Connecting to $address…")
                        onQuickPlayServer(version, address)
                    }
                ) { Text("JOIN") }
            },
            dismissButton = { TextButton(onClick = { showJoinDialog = false }) { Text("CANCEL") } }
        )
    }
}

@Composable
private fun SupaSidebar(
    onHome: () -> Unit,
    onVersions: () -> Unit,
    onAccounts: () -> Unit,
    onSettings: () -> Unit,
    onMultiplayer: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(66.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(22.dp))
            .background(Color(0xCC111A29))
            .border(1.dp, Color(0xFF27364A), RoundedCornerShape(22.dp))
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(
                Brush.linearGradient(listOf(SupaAccent, Color(0xFFFF9E42)))
            ),
            contentAlignment = Alignment.Center
        ) {
            Text("S", color = Color(0xFF1A160B), fontSize = 25.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(4.dp))
        SidebarItem("⌂", "HOME", true, onHome)
        SidebarItem("▦", "VERSIONS", false, onVersions)
        SidebarItem("◎", "ACCOUNTS", false, onAccounts)
        SidebarItem("⇄", "PLAY", false, onMultiplayer)
        Spacer(Modifier.weight(1f))
        SidebarItem("⚙", "SETTINGS", false, onSettings)
        Text("SUPA", color = SupaMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}

@Composable
private fun SidebarItem(symbol: String, label: String, selected: Boolean, onClick: () -> Unit) {
    val alpha by animateFloatAsState(
        targetValue = if (selected) 0.18f else 0.02f,
        animationSpec = tween(220),
        label = "sidebar-selection"
    )
    Column(
        modifier = Modifier
            .width(54.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(SupaAccent.copy(alpha = alpha))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(symbol, color = if (selected) SupaAccent else SupaMuted, fontSize = 20.sp)
        Text(label, color = if (selected) SupaText else SupaMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun GlassPanel(
    modifier: Modifier = Modifier,
    glow: Float = 0.0f,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xEE1A2638), Color(0xF2111A29), Color(0xEE101827))
                )
            )
            .border(
                BorderStroke(
                    1.dp,
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.20f + glow * 0.16f), Color(0xFF536984).copy(alpha = 0.42f), Color.White.copy(alpha = 0.06f))
                    )
                ),
                RoundedCornerShape(22.dp)
            )
            .padding(14.dp),
        content = content
    )
}

@Composable
private fun StatusPill(text: String) {
    Box(
        modifier = Modifier
            .clip(CircleShape)
            .background(SupaMint.copy(alpha = 0.12f))
            .border(1.dp, SupaMint.copy(alpha = 0.28f), CircleShape)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text, color = SupaMint, fontSize = 8.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
    }
}

@Composable
private fun MiniStat(
    modifier: Modifier,
    label: String,
    value: String,
    hint: String,
    onClick: () -> Unit
) {
    GlassPanel(
        modifier = modifier.fillMaxHeight().clickable(onClick = onClick)
    ) {
        Text(label, color = SupaMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(3.dp))
        Text(value, color = SupaText, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(hint, color = SupaMuted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun QuickAction(symbol: String, title: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(28.dp).clip(RoundedCornerShape(9.dp)).background(Color(0xFF26364B)),
            contentAlignment = Alignment.Center
        ) { Text(symbol, color = SupaAccent, fontSize = 15.sp) }
        Spacer(Modifier.width(9.dp))
        Text(title, color = SupaText, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.weight(1f))
        Text("›", color = SupaMuted, fontSize = 18.sp)
    }
}

@Composable
private fun SupaTaskRow(task: Task) {
    val progress by task.progress.collectAsStateWithLifecycle()
    val message by task.message.collectAsStateWithLifecycle()
    val rate by task.rateBytesPerSec.collectAsStateWithLifecycle()
    var elapsed by remember(task.id) { mutableLongStateOf(0L) }

    LaunchedEffect(task.id) {
        while (true) {
            delay(1_000)
            elapsed++
        }
    }

    val safeProgress = progress.coerceIn(0f, 1f)
    val eta = if (progress > 0.01f && progress < 1f) {
        (elapsed * (1f - safeProgress) / safeProgress).toLong()
    } else null

    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (message != null) {
                AndroidStringText(text = message!!, style = MaterialTheme.typography.labelMedium.copy(color = SupaText))
            } else {
                Text("Background task", color = SupaText, fontSize = 10.sp)
            }
            Spacer(Modifier.weight(1f))
            Text(
                text = if (progress >= 0f) "${(safeProgress * 100).roundToInt()}%" else "WORKING",
                color = SupaAccent,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }
        if (progress < 0f) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(4.dp), color = SupaAccent, trackColor = Color(0xFF354255))
        } else {
            LinearProgressIndicator(
                progress = { safeProgress },
                modifier = Modifier.fillMaxWidth().height(4.dp),
                color = SupaAccent,
                trackColor = Color(0xFF354255)
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Elapsed ${formatClock(elapsed)}", color = SupaMuted, fontSize = 8.sp)
            eta?.let { Text("  •  Est. ${formatClock(it)} left", color = SupaMuted, fontSize = 8.sp) }
            rate?.let { Text("  •  ${com.movtery.zalithlauncher.utils.file.formatFileSize(it)}/s", color = SupaMuted, fontSize = 8.sp) }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { TaskSystem.cancelTask(task.id) }) {
                Text("CANCEL", color = Color(0xFFFFA1A1), fontSize = 8.sp)
            }
        }
    }
}

private fun formatClock(seconds: Long): String {
    val safe = seconds.coerceAtLeast(0)
    val minutes = safe / 60
    val secs = safe % 60
    return "%02d:%02d".format(minutes, secs)
}
