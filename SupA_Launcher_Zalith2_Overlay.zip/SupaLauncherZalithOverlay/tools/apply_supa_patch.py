#!/usr/bin/env python3
"""Apply SupA's launcher UI and brand overlay to a Zalith Launcher 2 checkout."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
LAUNCHER = ROOT / "ZalithLauncher/src/main/java/com/movtery/zalithlauncher/ui/screens/content/LauncherScreen.kt"
PROPS = ROOT / "ZalithLauncher/gradle.properties"
GRADLE = ROOT / "ZalithLauncher/build.gradle.kts"
MARKER = "SupaDashboard(\n"


def replace_launcher_screen() -> None:
    if not LAUNCHER.is_file():
        raise SystemExit(f"Cannot find {LAUNCHER}. Run this script from a ZalithLauncher2 repository root.")
    source = LAUNCHER.read_text(encoding="utf-8")
    if MARKER in source:
        print("[SupA] LauncherScreen already patched.")
        return

    start_token = "@Composable\nfun LauncherScreen("
    end_token = "@Composable\nprivate fun ContentMenu("
    start = source.find(start_token)
    end = source.find(end_token, start + 1)
    if start < 0 or end < 0:
        raise SystemExit("LauncherScreen.kt structure differs from the expected Zalith 2 source. No files were changed.")

    replacement = '''@Composable
fun LauncherScreen(
    backStackViewModel: ScreenBackStackViewModel,
    navigateToVersions: (Version) -> Unit,
    onLaunchGame: (Version?) -> Unit,
    onQuickPlayServer: (Version?, String) -> Unit,
    onOpenLink: (String) -> Unit,
    startGuideOnce: (GuideKeys.Keys) -> Unit,
) {
    LaunchedEffect(Unit) {
        startGuideOnce(GuideKeys.Main)
    }

    BaseScreen(
        screenKey = NormalNavKey.LauncherMain,
        currentKey = backStackViewModel.mainScreen.currentKey
    ) { _ ->
        SupaDashboard(
            backStackViewModel = backStackViewModel,
            onLaunchGame = onLaunchGame,
            onQuickPlayServer = onQuickPlayServer,
            onOpenVersionSettings = navigateToVersions,
            onOpenLink = onOpenLink
        )
    }
}

'''
    LAUNCHER.write_text(source[:start] + replacement + source[end:], encoding="utf-8")
    print("[SupA] Replaced the launcher home screen while keeping Zalith's navigation and launch callbacks.")


def set_property(text: str, key: str, value: str) -> str:
    pattern = re.compile(rf"(?m)^\s*#?\s*{re.escape(key)}=.*$")
    line = f"{key}={value}"
    if pattern.search(text):
        return pattern.sub(line, text, count=1)
    return text.rstrip() + "\n" + line + "\n"


def apply_brand() -> None:
    if not PROPS.is_file() or not GRADLE.is_file():
        raise SystemExit("Could not find the ZalithLauncher Gradle module files.")
    properties = PROPS.read_text(encoding="utf-8")
    for key, value in {
        "launcher_name": "SupALauncher",
        "launcher_app_name": "SupA Launcher",
        "launcher_short_name": "SUPA",
        "url_home": "https://github.com/ZalithLauncher/ZalithLauncher2",
        "launcher_version_code": "300001",
        "launcher_version_name": "1.0.0",
    }.items():
        properties = set_property(properties, key, value)
    PROPS.write_text(properties, encoding="utf-8")

    gradle = GRADLE.read_text(encoding="utf-8")
    old = "applicationId = zalithPackageName"
    new = 'applicationId = "app.supacloud.supa"'
    if new not in gradle:
        if old not in gradle:
            raise SystemExit("Could not find the module applicationId line; stopped instead of guessing.")
        gradle = gradle.replace(old, new, 1)
        GRADLE.write_text(gradle, encoding="utf-8")
    print("[SupA] Brand, version and unique application ID applied. Original namespace and launch engine are retained.")


def main() -> None:
    replace_launcher_screen()
    apply_brand()
    print("[SupA] Overlay applied successfully.")


if __name__ == "__main__":
    main()
